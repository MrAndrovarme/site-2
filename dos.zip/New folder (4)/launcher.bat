@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
title Free IP Stresser Booter V6 - FIXED
color 0A

cls
echo.
echo  ╔════════════════════════════════════╗
echo  ║   Free IP Stresser Booter V6       ║
echo  ║ Powered by nightmare-stresser.co   ║
echo  ╚════════════════════════════════════╝
echo.

REM Try multiple Python paths (handles Store, official, etc.)
set PYTHONS=
set PYTHONS=%PYTHONS% python;
set PYTHONS=%PYTHONS% py;
set PYTHONS=%PYTHONS% python3;
set PYTHONS=%PYTHONS% C:\Python*\python.exe;
set PYTHONS=%PYTHONS% C:\Users\%USERNAME%\AppData\Local\Programs\Python\*\python.exe;

echo [SCAN] Finding working Python...

:find_python
for %%p in (%PYTHONS%) do (
    where %%p >nul 2>&1 && (
        for /f "tokens=*" %%i in ('where %%p') do (
            set TEST_PYTHON=%%i
            echo   Testing: !TEST_PYTHON!
            
            REM Test if pip works
            !TEST_PYTHON! -m pip --version >nul 2>&1 && (
                REM Test if requests imports
                !TEST_PYTHON! -c "import requests; print('OK')" >nul 2>&1 && (
                    set PYTHON_PATH=!TEST_PYTHON!
                    goto python_found
                )
            )
        )
    )
)

echo [ERROR] No working Python found!
echo.
echo FIX: Download Python from python.org (check "Add to PATH")
echo OR run: python -m pip install requests colorama --user
pause
exit /b 1

:python_found
echo.
echo [✓] PERFECT Python: %PYTHON_PATH%
echo.

REM Install modules
echo [INSTALL] Fixing modules...
%PYTHON_PATH% -m pip install --upgrade pip --user --quiet >nul 2>&1
%PYTHON_PATH% -m pip install colorama requests --user --force-reinstall --quiet >nul 2>&1

REM Final verification
%PYTHON_PATH% -c "import sys,requests,colorama; print('✓ ALL MODULES OK -', sys.executable)" 

if not exist "stresser.py" (
    echo [ERROR] Save Python code as stresser.py!
    pause
    exit /b 1
)

REM Proxy list
echo [PROXY] Downloading...
powershell -c "$r=Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt' -UseBasicParsing -ErrorAction SilentlyContinue; $r.Content | Out-File proxy_list.txt"

echo.
echo [LAUNCH] Nightmare Stresser V6 - READY!
echo.
%PYTHON_PATH% -u stresser.py

pause