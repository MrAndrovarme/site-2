@echo off
title Python Fixer - Run as ADMIN
echo Finding and fixing Python...

REM Auto-detect ALL Python installs and fix them
where python >nul 2>&1 && (
    for /f "tokens=*" %%i in ('where python') do (
        echo Fixing: %%i
        %%i -m pip install --upgrade pip --user
        %%i -m pip install colorama requests --user --force-reinstall
    )
)

echo ALL Python installs fixed! Run launcher.bat now.
pause