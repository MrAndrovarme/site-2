@echo off
title Python Module Diagnostic
color 0E

echo ========================================
echo     Python Module Diagnostic Tool
echo ========================================
echo.

echo [*] Checking Python installations...
echo.

echo 1. Which python is being used?
where python
echo.

echo 2. Python version:
python --version
echo.

echo 3. Where does pip install to?
pip show pystyle 2>nul | find "Location"
if %errorlevel% neq 0 (
    echo [!] pystyle not found in pip
)
echo.

echo 4. Checking if Python can find pystyle:
python -c "import pystyle; print('✓ pystyle found at:', pystyle.__file__)" 2>nul
if %errorlevel% neq 0 (
    echo [✗] pystyle NOT found by Python
)
echo.

echo 5. List of installed packages:
pip list | findstr pystyle
if %errorlevel% neq 0 (
    echo [!] pystyle not in pip list
)
echo.

echo 6. Python's sys.path:
python -c "import sys; print('\n'.join(sys.path))"
echo.

echo ========================================
echo Fixing the issue...
echo ========================================
echo.

:: Method 1: Install specifically for this Python
echo [*] Method 1: Installing directly with python -m pip...
python -m pip install --upgrade pystyle --force-reinstall
echo.

:: Method 2: Install to user site
echo [*] Method 2: Installing to user site...
python -m pip install --user pystyle --force-reinstall
echo.

:: Method 3: Install with no cache
echo [*] Method 3: Installing with no cache...
python -m pip install --no-cache-dir pystyle --force-reinstall
echo.

:: Verify again
echo [*] Verifying installation...
python -c "import pystyle; print('✓ SUCCESS! pystyle is now available')" 2>nul
if %errorlevel% equ 0 (
    echo [✓] Fixed! pystyle is now working.
) else (
    echo [✗] Still not working. Let's try more fixes...
    
    :: Try installing from GitHub
    echo.
    echo [*] Method 4: Installing from GitHub...
    python -m pip install git+https://github.com/billythegoat356/pystyle.git
    
    :: Final check
    python -c "import pystyle; print('✓ SUCCESS!')" 2>nul
    if %errorlevel% equ 0 (
        echo [✓] Fixed with GitHub install!
    ) else (
        echo [✗] All methods failed.
    )
)

echo.
pause