@echo off
title Simple Minecraft IP Resolver
color 0A

:start
cls
echo.
echo Enter Minecraft server (example: mc.hypixel.net)
echo.
set /p server="Server: "

if "%server%"=="" goto start

cls
echo Resolving %server%...
echo.

:: Use ping to get IP
for /f "tokens=2 delims=[]" %%i in ('ping -n 1 %server% 2^>nul') do (
    set ip=%%i
    goto found
)

:found
if "%ip%"=="" (
    echo Could not resolve IP address
) else (
    echo ================================
    echo Server: %server%
    echo IP Address: %ip%
    echo ================================
    
    :: Copy to clipboard option
    echo.
    echo Copy to clipboard? (Y/N)
    choice /c yn /n
    if errorlevel 2 goto start
    echo %ip%| clip
    echo Copied!
)

echo.
pause
goto start