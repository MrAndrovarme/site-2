@echo off
title Brutalize Simple Launcher
color 0A

echo Attempting to run brutalize.py...
echo.

:: Check if file exists
if not exist "brutalize.py" (
    echo ERROR: Cannot find brutalize.py in:
    echo %cd%
    echo.
    echo Please make sure the batch file is in the same folder as brutalize.py
    pause
    exit /b 1
)

:: Try to run it
echo Found brutalize.py, attempting to run...
echo.
python brutalize.py

:: If it fails, show error
if %errorlevel% neq 0 (
    echo.
    echo Script crashed with error code: %errorlevel%
    echo.
    echo Trying to install pystyle...
    pip install pystyle
    
    echo.
    echo Try running again manually with:
    echo python brutalize.py
)

pause