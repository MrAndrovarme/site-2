@echo off
title Package Installer
color 0A

echo ========================================
echo     Installing Required Packages
echo ========================================
echo.

:: Check if Python is installed
echo [*] Checking Python installation...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Python is not installed!
    echo [*] Please install Python first from: https://www.python.org/downloads/
    pause
    exit /b 1
) else (
    python --version
)

echo.
echo [*] Installing pystyle...
pip install pystyle
if %errorlevel% equ 0 (
    echo [✓] pystyle installed successfully!
) else (
    echo [*] Trying alternative method...
    python -m pip install pystyle
)

echo.
echo [*] Installing getpass (usually built-in, but ensuring)...
pip install getpass4
if %errorlevel% equ 0 (
    echo [✓] getpass4 installed successfully!
) else (
    echo [*] Trying alternative method...
    python -m pip install getpass4
)

echo.
echo [*] Installing colorama (optional but helpful)...
pip install colorama
if %errorlevel% equ 0 (
    echo [✓] colorama installed successfully!
) else (
    python -m pip install colorama
)

echo.
echo ========================================
echo Installation complete!
echo.
echo Installed packages:
pip list | findstr pystyle
pip list | findstr getpass
pip list | findstr colorama

echo.
pause